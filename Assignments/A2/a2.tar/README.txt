Author: Yordan Slavchev
Student ID: 101249727

Compilation: gcc -o a2 a2-posted.c
To run: ./a2

Files: REAMDE.txt, a2-posted.c

Description: The program encodes ASCII characters into cipher text ASCII values and the reverse - decodes cipher ASCII values into ASCII plain text characters using a cipher KEY and an INITIAL COUNTER that increases with each character encoded or decoded. 
The program will print out the coded or decoded msg. 
